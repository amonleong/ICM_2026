### ========================================================
### Statistical Software: R and SAS, 26.10.2025
### Group B, R Lecture 12: Modern R with tydiverse
### ========================================================
#load("GrB_RLecture11.RData")


#The tidyverse is an opinionated collection of R packages designed for data science. 
#All packages share an underlying design philosophy, grammar, and data structures.
#Install the complete tidyverse with:
#install.packages("tidyverse") #https://www.tidyverse.org/packages/

#Tidyverse is an R programming package that helps to transform and better present data. It assists with data import, 
#tidying, manipulation, and data visualization. 
#The tidyverse package is open source, meaning that it is freely available to use and is constantly being modified and improved.

#The tidyverse package in a suite of packages that provide key functions for data transformation and use. 
#The core packages included in tidyverse are ggplot2, tidyr, readr, dplyr, stringr, purrr, and forcats, 
#although there are various additional packages that can be installed separately.

#see few description in https://study.com/academy/lesson/tidyverse-in-r-programming-definition-functions.html #!!



#More exercises in: https://b-rodrigues.github.io/modern_R/descriptive-statistics-and-data-manipulation.html#the-tidyverses-enfant-prodige-dplyr
#and https://rpubs.com/StefanoSanfilippo/654777

library(dplyr)
library(tidyr)

#The databases to be used are already preloaded in RStudio: iris, mtcars and Indometh.

?iris  #flowers: This famous (Fisher's or Anderson's) iris data set gives the measurements in centimeters of the variables sepal length and width and petal length and width, respectively, for 50 flowers from each of 3 species of iris. The species are Iris setosa, versicolor, and virginica.
?mtcars #The data was extracted from the 1974 Motor Trend US magazine, and comprises fuel consumption and 10 aspects of automobile design and performance for 32 automobiles (1973-74 models).
?Indometh #The Indometh data frame has 66 rows and 3 columns of data on the pharmacokinetics of indometacin 

######################################################
# efficient procedures using tidyverse
#####################################################

#######################################################
# Variable selection
#######################################################
#using tidyverse:
View(mtcars)
select(mtcars, mpg, cyl, gear) # Selection by variable name
select(mtcars, 1,2,10) # Selection by position

#using R base:
# mtcars[,c("mpg","cyl","gear")] # by name
# mtcars[,c(1,2,10)] # By number or position
# subset(mtcars, select = c(1,2, 10)) # by position
# subset(mtcars, select = c("mpg","cyl","gear")) # by name


########################################################
#Create new variables
########################################################
#using tidyverse:
#Using function mutate().
mutate(mtcars, # Create a variable that calculates the ratio of mpg to hp.
       ratio.mpg.hp = mpg/hp)

#using R base:
# mtcars$ratio.mpg.hp <- mtcars$mpg/mtcars$hp
# transform(iris, petal.ratio = Petal.Length/Petal.Width)


########################################################
#Selection of observations or tidyverse lines
########################################################
#With dplyr you use filter ().
filter(mtcars, cyl== 8)

#using R base:
# mtcars[mtcars$cyl==8,]
# subset(mtcars, cyl==4)


########################################################
#Sorting the tables according to a variable
########################################################
#tidyverse
#With dplyr the arrange () function is typical
arrange(iris, desc(Species), Sepal.Width) #sort iris by Species (descending) and Sepal.Width (ascending)

#using R base:
# iris[order(rev(iris$Species), iris$Sepal.Length),]
# iris[order(rev(iris[,1]), iris[,5]),]
# iris[with(iris, order(rev(Species), Sepal.Length)),]

########################################################
#Summary of observations or lines
########################################################
#tidyverse
#The classic function is summarize(). Summarize_at() also works for many variables; and also summarize() combined with across(), a new function introduced in dplyr in the June 2020 update.

#The pipe operator, written as %>% , is a longstanding feature 

# Classical form with tidyverse
mtcars %>%
  summarise(mpg.mean =mean(mpg),
            mpg.median=median(mpg),
            hp.mean=mean(hp),
            hp.median=median(hp))

# Shortcuts if the variables and functions to be summarized are many
mtcars %>% # with summarise_at()
  summarise_at (.vars = c("mpg", "hp"),
                .funs = c("mean", "median"))

mtcars %>% # with summarise() y across()
  summarise(across(.cols= c(mpg, hp),
                   .fns= list(Mean= mean, Median= median)))

#using R base:
#manually:
data.frame(mpg.mean = mean(mtcars$mpg),
           mpg.median= median(mtcars$mpg),
           hp.mean= mean(mtcars$hp),
           hp.median= median(mtcars$hp))
#with aggregate
aggregate(formula = cbind(mpg, hp) ~ 1, data = mtcars,FUN = function(x){c(mean = mean(x), median = median(x))})


########################################################
#Combination of tables
########################################################
#tidyverse

#Consider the dataframes:
?band_members
band_members
band_instruments
band_instruments2


#Combining with tidyverse:
# Keep matching names
inner_join(band_members, band_instruments, by = "name") #only the commons
# Keep all lines:
full_join(band_members, band_instruments, by = "name")  #join all
# Keep all lines from the first table:
left_join(band_members, band_instruments, by = "name")  #all but only for the left set
# Keep all the lines of the second table:
right_join(band_members, band_instruments, by = "name")  #all but only for the right set
# The columns to be combined can have different names:
inner_join(band_members, band_instruments2, by = c("name" = "artist")) #better than merge


#using R base:
# Keep matching names
merge(band_members, band_instruments, by = "name")
# Keep all lines:
merge(band_members, band_instruments, by = "name", all = TRUE)
# Keep all lines from the first table:
merge(band_members, band_instruments, by = "name", all.x = TRUE)
# Keep all the lines of the second table:
merge(band_members, band_instruments, by = "name", all.y = TRUE)
# The columns to be combined can have different names:
merge(band_members, band_instruments2, by.x = "name", by.y = "artist")

########################################################
#Grouping operations
#Summarizing grouped lines
########################################################
#Grouping with dplyr
#The most typical dplyr function is group_by()
#ex1
mtcars %>% group_by(cyl) %>% summarise(mean_weight = mean(wt))
#ex2
mtcars %>% 
  group_by(carb, gear) %>% 
  summarise(mpg.mean = mean(mpg),
            mpg.median = median(mpg),
            hp.mean = mean(hp),
            hp.median = median(hp)) %>%
  arrange(gear)%>% #sort
  ungroup() # remove from the analysis that follows

#exercise: now add a column with the variance of hp
#the use of ungroup():If we didn't use the ungroup() function then the rows of the data frame would still be grouped, 
#which could have unintended consequences when we perform more calculations later on. See example in: https://www.statology.org/dplyr-ungroup/

#R base:
mtcars_by <- by(mtcars, 
                INDICES = list(mtcars$carb, mtcars$gear),
                FUN = function(x){
                  data.frame(carb = unique(x$carb),
                             gear = unique(x$gear),
                             mpg.mean = mean(x$mpg),
                             mpg.median = median(x$mpg),
                             hp.mean = mean(x$hp),
                             hp.median = median(x$hp))
                })
# Merge the result into a data frame
do.call(rbind, mtcars_by)

#other possibility in R base
aggregate(formula = cbind(mpg, hp) ~ carb + gear,
          data = mtcars,
          FUN = function(x){
            c(mean = mean(x), median = median(x))})


########################################################
#Create new columns with grouped calculations
########################################################

library(dplyr)
library(tidyr)

#For example creating a centered column that quantifies the difference of a measurement 
# from the average calculated by the group to which the observation belongs.

#Creation with tidyverse:
iris %>% 
  group_by(Species) %>% 
  mutate(Sepal.Length.centered = Sepal.Length - mean(Sepal.Length)) %>% 
  ungroup()

#Problem: use this to center variable mpg (df cars) in a new variable mpg.diff grouped by cyl and save in df mtcars_by22
mtcars_by22<-mtcars %>% 
  group_by(cyl) %>% 
  mutate(mpg.diff = mpg - mean(mpg)) %>% 
  arrange(cyl)%>% #sort
  ungroup()


#R base:
#first alternative:
iris$Sepal.Length.centered <- ave(iris$Sepal.Length,
                                  iris$Species,
                                  FUN = function(x) x - mean(x))
#second alternative:
# First work with by ()
mtcars_by22 <-with(mtcars,by(mtcars,
                            cyl,
                            FUN = function(y){y$mpg.diff <- y$mpg - mean(y$mpg)
                            return(y)}))
# Then combine the result into a data frame
do.call(rbind, mtcars_by2)


#################################################################
#Filtering of lines according to conditions evaluated in the groups
##################################################################
#For example, setting the maximums for each group. 
# In the case of mtcars, 
# it would, for example, filter the maximum hp, according to the number of cylinders.

#tidyverse:
#In this case using group_by () and filter ().
mtcars %>% 
  group_by(cyl) %>% 
  filter(hp == max(hp))

#R base
#In this case, the by () function is also used
max_hp <- with(mtcars, by(mtcars,
                          cyl,
                          FUN = function(xm){xm[xm$hp== max(xm$hp),]}))
do.call(rbind,max_hp)



#################################################################
# Create elegant visualization using ggplot2()
#################################################################

#see in: https://ggplot2.tidyverse.org/

#see templates in: https://r-charts.com/ggplot2/

# The easiest way to get ggplot2 is to install the whole tidyverse:
#install.packages("tidyverse")

# Alternatively, install just ggplot2:
#install.packages("ggplot2")

# Or the development version from GitHub:
# install.packages("devtools")
#devtools::install_github("tidyverse/ggplot2")


#See the Cheatsheet: https://github.com/rstudio/cheatsheets/blob/master/data-visualization-2.1.pdf

#It s hard to succinctly describe how ggplot2 works because it embodies a 
#deep philosophy of visualisation. 
#However, in most cases you start with ggplot(), supply a dataset and aesthetic mapping 
#(with aes()). You then add on layers (like geom_point() or geom_histogram()), 
#scales (like scale_colour_brewer()), faceting specifications (like facet_wrap()) 
#and coordinate systems (like coord_flip()).

library(ggplot2)
#BAR PLOT
ggplot(mpg, aes(class)) + 
  geom_bar()
#STACKED BAR PLOT
ggplot(mpg, aes(class, fill = drv)) + 
  geom_bar()

#BAR PLOT WITH A 3TH QUANTITATIVE VARIABLE
ggplot(mpg, aes(class, fill = hwy, group = hwy)) + 
  geom_bar()

#more examples in: https://ggplot2-book.org/

#scatterplot with regression using base package
#https://r-charts.com/correlation/scatter-plot-regression-line/
# Data. Model: Y = X ^ 2
set.seed(54)
x <- seq(0, 10, by = 0.05)
y <- x ^ 2 + rnorm(length(x), sd = 20)

# Linear model
model <- lm(y ~ x)

# Scatter plot and linear regression line
plot(x, y, pch = 16)
abline(model, col = 4, lwd = 3)

# Text
coef <- round(coef(model), 2)
text(2, 70,  paste("Y = ", coef[1], "+", coef[2], "x"))

#scatterplot using gglot2
library(ggplot2)
# Basic scatter plot
ggplot(mtcars, aes(x=wt, y=mpg)) + geom_point()
# Change the point size, and shape
ggplot(mtcars, aes(x=wt, y=mpg)) +
  geom_point(size=2, shape=23)

# Regression confidence interval
ggplot(mtcars, aes(x=wt, y=mpg)) + 
  geom_point()+
  geom_smooth(method=lm, se=T)
# Loess method
ggplot(mtcars, aes(x=wt, y=mpg)) + 
  geom_point()+
  geom_smooth()


################################

#proposed exercises

################################

#Exercise 1---------------------------------:
#using:
?Indometh
#The Indometh data frame has 66 rows and 3 columns of data on the pharmacokinetics of indometacin (or, older spelling, ‘indomethacin’).

dataIndometh<-Indometh
# compute mean and sdv of Indometh by group time 

#group df data by time and compute mean and sd in each group. Sort all by time ascending.
dataIndometh<-Indometh %>% 
  group_by(time) %>% 
  summarise(conc.mean = mean(conc),
            conc.sdv = sd(conc)) %>%
  arrange(time)%>%
  ungroup() # remove from the analysis that follows

dataIndometh

class(dataIndometh)

#Exercise 2-------------------------------:

#The object data(prostate), see in: ??prostate at the link faraway::prostate from library(faraway),
#contains the data frame prostate . The prostate data frame has 97 rows and 9 columns. A study
#on 97 men with prostate cancer who were due to receive a radical prostatectomy. Source from Source
#Andrews DF and Herzberg AM (1985): Data. New York: Springer-Verlag. The variables of prostate
#are the followings:
# id: [,1] lcavol Ig, common standardized fertility measure.
# id: [,2] lweight, log(prostate weight).
# id: [,3] age, age.
# id: [,4] lbph, log(benign prostatic hyperplasia amount).
# id: [,5] svi, seminal vesicle invasion.
# id: [,6] lcp, log(capsular penetration).
# id: [,7] gleason, Gleason score.
# id: [,8] pgg45, percentage Gleason scores 4 or 5.
# id: [,9] lpsa, log(prostate specic antigen).
#Nota: The data comes from data frame prostate of the package faraway of R to be charged using the
#instruction: data(prostate).

library(faraway)
data(prostate)
prostate<-prostate


#plot the number of patients by age
library(ggplot2)

#represent the number of patients by age in subgroups of svi
ggplot(prostate, aes(age, fill = factor(svi))) + 
  geom_bar()

#create new group based on age, and divided in 3 quartiles:
library(Hmisc)
prostate$age.group<-cut2(prostate$age, quantile(prostate$age, c(0.3, 0.9)))
summary(prostate$age.group)

#present only minimim value of lcp by age.group and not all variables
res1<-prostate %>% 
  group_by(age.group) %>% 
  filter(lcp == min(lcp))
res1

#sorted by age.group (DESCENDING) and lcavol (ASCENDIN)
res2<-arrange(res1, desc(age.group),  lcavol)
res2


# Exercise 3--------------------------------------:
#Using dataframe prostate
#do a function that allows change only when -> lcavol > cut.off (ex: cut.off = 0.5) by mean(lcavol) 
#return number of changes and dataframe changed



#alternative:
change_lcavol_by_age_mean <- function(dataframe, cut_off=0.5) {

  #dataframe = prostate
  #cut_off = 0.5
  # Calculate mean lcavol for each age group
  mean_lcavol <- dataframe %>%
    summarise(mean_lcavol = mean(lcavol))
  
  # Modify lcavol based on cut_off and mean for each group
  modified_data <- dataframe %>%
    mutate(
      lcavol_modified = ifelse(lcavol > cut_off, mean_lcavol, lcavol)
    )
  
  # Combine mean calculation and modified data
  return(list(
    num_changes = sum(modified_data$lcavol != (modified_data$lcavol_modified)),
    modified_dataframe = ungroup(modified_data)
  ))
}


#use the function
library(faraway)
data(prostate)
res<-change_lcavol_by_age_mean(dataframe=prostate,cut_off = 0.7)
res #only see number of changes



#using r basic
change.lcavol<- function(cut.off = 0.5){
  #new dataframe
  prostate.changed<-prostate
  #create the variable to change lcavol
  prostate.changed$lcavol.categorized <- NA
  #loop for 
  changes<-0
  for(i in 1:dim(prostate.changed)[1]){
    #prostate$lcavol.categorized[i]<- ifelse(prostate$lcavol[i] > mean(prostate$lcavol), "Young", 1)
    #i<-1
    if(prostate.changed$lcavol[i]>cut.off){
      prostate.changed$lcavol.categorized[i]<-mean(prostate.changed$lcavol)
      changes<- changes+1
      cat("Change in line: ", i,sep = "",fill = T)
    }
    
  }
  
  prostate.changed <- prostate
  return(list(changes,prostate.changed))
}



#use the function
library(faraway)
data(prostate)
res<-change.lcavol(cut.off = 0.7)
res[[1]] #only see number of changes


#Exercise 4------------------------------------------:
#Using dataframe iris
#Create a function with the name of Function1,  with a parameter called Option1.
#If you indicates Option.1 = True in Function1, that allows you:
#Create subgroups in a dataframe for a requested variable. 
#As an argument the function would need the name of the dataframe, 
#the name of the variable to be grouped and the limits of the categories to be constructed 
#(ex: 2, 3, 4, ...). As a result, you should offer a statistic with the subgroups AND SPECIES and a 
#list containing the new dataframe with the new grouping.

iris
Function1<- function(Option1=1, datafr=iris, variable.pos=3, limits.g=c(1.1,2,5), var.to.describe=1){
  library(Hmisc)
  library(dplyr)
  library(tidyr)
  datafr$new.group<-NA #NA VARIABLE
  if(Option1==1){
    datafr$new.group<-cut2(datafr[,3], limits.g)
    print("New subgroups")
    print(summary(datafr$new.group)) #print summary of new group
    
    #DESCRIBE DATAFRAME BY NEW SUBGROUPS AND SPECIES
    cat("The analyzed variable by subgroups and species  is: ", names(datafr)[1],fill = T,sep="")
    datafr1<-datafr %>% 
      group_by(new.group, Species) %>% 
      summarise(var.mean = mean(datafr[,1]),
                var.sdv = sd(datafr[,1])) %>%
      arrange(new.group)%>%
      ungroup() # remove from the analysis that follows
    
  }
  
  return(datafr1)
  
}

#run function
Function1()
