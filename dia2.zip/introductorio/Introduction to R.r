
# Statistical Software: R and SAS 2025/2026

#############################################################################################################
#             Introduccion to RSTUDIO and R: BASIC SKILLS
#############################################################################################################
# 2025

# Toni Monleon Getino- Departament of Statistics. University of Barcelona
# amonleong@ub.edu
# See a good introduction at: http://cran.r-project.org/doc/manuals/R-intro.html 



# Load R (https://www.r-project.org/) & RSTUDIO (https://www.rstudio.com/products/rstudio/download/) 

# From  "R for Beginners" https://cran.r-project.org/doc/contrib/Paradis-rdebuts_en.pdf
#The goal of the present document is to give a starting point for people newly
#interested in R. I chose to emphasize on the understanding of how R works,
#with the aim of a beginner, rather than expert, use. Given that the possibilities
#offered by R are vast, it is useful to a beginner to get some notions and
#concepts in order to progress easily. I tried to simplify the explanations as
#much as I could to make them understandable by all, while giving useful
#details, sometimes with tables.


# Additional information at https://monashbioinformaticsplatform.github.io/r-intro/

#an interesting introduction: https://moderndive.com/1-getting-started.html


#####################################################
### Creating, listing, and removing objects in memory
#####################################################


n<-15
n

n->5
n

6 -> n
n


# If the object already exists, its previous value is erased after allocation (modification
# Affects only objects in memory, no data on the disk). The value assigned this way can
# Be the result of an operation and / or a function:
 n <- 10 + 2
 n

 n <- 3 + rnorm(1)
 n
# The rnorm function (1) generates one random data from a normal distribution with mean
# 0 and variance 1. Note that you can write an expression without assigning its value to an object;
# In this case the result will be visible on the screen but will not be stored in memory:

# an example of use of simulation
# Get a random log-normal distribution
r <- rlnorm(1000)
# Get the distribution without plotting it using tighter breaks
h <- hist(r, plot=F, breaks=c(seq(0,max(r)+1, .1)))
# Plot the distribution using log scale on both axes, and use
# blue points
plot(h$counts, log="xy", pch=20, col="blue",
     main="Symptoms of Lung Cancer after treatment",
     xlab="Time (month)", ylab="Frequency")


#A nice gallery of plots and graphs: https://www.r-graph-gallery.com/

################################################################
# do here a plot example
###############################################################



#do operations
 (10 + 2) * 5

# Or alphanumeric text variables:
 name <- "Carmen"; n<- 76; n1 <- 10; n2 <- 100; m <- 0.5
 ls() # List all memory variables

# Note the use of the semicolon to separate different commands on the same line.
# If you want to list only those objects that contain a particular character, you can use the option
# Pattern (which can be abbreviated as pat):
 ls(pat = "m")
 

# To delete objects in memory, we use the function rm (): rm (x) deletes the object x,
# Rm (x, y) deletes both x and y objects, and rm (list = ls ()) deletes all objects in memory;
# The same options mentioned for the function ls () can be used to selectively erase
# Some objects: rm (list = ls (pat = "m")).

ls()
rm(list=ls(pat="m"))
ls()  # The object containing the character m is no longer in memory
rm (list = ls ())



# Online help --------------------------------------------- ------------------------------:
# Online help of R gives very useful for how to use the information. the
# Support is available directly for a given function. For example:

 ?lm
# Show within R, the help function lm () (linear model). The command help (lm) or
# Help ("lm") has the same effect

help("*")   #Arithmetic Operators

# By default, the function help only searches in the packages that are loaded into memory. the
# Try.all.packages option, which by default is FALSE (false) enables search
# All available packages if its value is changed to TRUE (true):

help("bs")
# Error in help("bs") : No documentation for ?bs? in specified
# packages and libraries:
# you could try ?help.search("bs")?
help("bs", try.all.packages=TRUE)
# topic bs is not in any loaded package
# but can be found in package splines in library 
help.search("logistic regression")
help.search("R help")


#####################################################
#### EXAMPLE OF USING A LIBRARY
#####################################################

# Most of the libraries available in the local version of R must be loaded before
# You can use them. For example, to load the library can use dices
# The next instruction

# Un ejemplo: A Collection of Functions to Experiment Dice Rolls
# A collection of functions to simulate dice rolls and the like. In particular, experiments and exercises can be performed looking at combinations and permutations of values in dice rolls and coin flips, together with the corresponding frequencies of occurrences. When applying each function, the user has to input the number of times (rolls, flips) to toss the dice. Needless to say, the more the tosses, the more the frequencies approximate the actual probabilities. Moreover, the package provides functions to generate non-transitive sets of dice (like Efron's) and to check whether a given set of dice is non-transitive with given probability.
install.packages("TeachingDemos")
library(TeachingDemos)
# 10 rolls of 4 fair dice
dice(10,4, plot.it=TRUE)



# During an R session you can save the history of all commands executed
# Far from the toolbar:
# File Save History.



#####################################################
#### MANAGING DATA WITH R
#####################################################

# -------------------------------------------------------------------------------
# THE OBJECTS

# We have seen that R works with objects which have name and content, but also
# Attributes that specify the type of data represented by the object. To understand the usefulness
# Of these attributes, consider a variable that takes the values 1, 2, or 3: such a variable could already
# Be an integer (for example, the number of children), or a variable code
# Categorical (eg sex of patients in a clinical trial).

# Every object has two intrinsic attributes: type and length. The type refers to the basic class
# Of items in the object; There are four main types: numeric, character, complex, and
# Logical (FALSE [False] TRUE or [True]). There are other types, but do not represent data as
# Such (for example functions or expressions). The length is simply the number of elements in
# The object. To see the type and length of an object you can use the functions mode and length,
# Respectively:
 x <- 1
 mode(x)
 length(x)
 
 x.vector <- c(1,3,5,7)
 mode(x.vector)
 length(x.vector)

 #an example:
 A <- "Hospital A"; compar <- TRUE; z <- 1i
 mode(A); mode(compar); mode(z)

 x <- 5/0
 x    #infinit number

 exp(x)
 exp(-x)
 x - x   #undetermined or NaN
 
# Object types and their representation in R ------------------------------------.
# object                types                                
#
# Vector numeric, character, complex or logical No
# Numeric character factor or not
# Numerical arrangement, character, complex or logical No
# Numerical matrix, character, complex or logical No
# Data.frame numeric, character, complex or logical Yes
# Ts numeric, character, complex or logical Yes
# Numerical list, character, complex, logical If
# Function, expression,. . .


#####################################################
#### READ FILES, WRITE FILES, GENERATE DATA
#####################################################

# R uses the working directory to read and write files. To know what is this directory
# You can use the command getwd () (get working directory) To change the working directory,
# The fucni'on setwd () is used; eg setwd ("C: / data") or setwd ("/ home / paradis / R ").
# You need to provide the address (path) complete the file if it is not in the
# Working directory.


# R can read data stored as text files (ASCII) with the following functions:
# Read.table (and variants, see below), scan and read.fwf. R can also read files
# In other formats (Excel, SAS, SPSS,...), And accessing SQL data bases such, but the functions
# Necessary are not included in the base package. Although this feature is very useful for
# Advanced user, we restrict to describe the functions to read files in ASCII format
# Only the read.table function creates a data frame (data frame) and is the way more
# Usual to read data in tabular form. For example if we data.dat file name, the command:
# IMPORTANT!!!! first to next sentence use:  setwd(...)
 
 mydata<- read.table("BP DRUG TRIAL.txt", header=TRUE, quote="\"")
 mydata
 mode(mydata)
 length(mydata)
 dim(mydata)
 
 
 #Create a simple data-frame
 
 example.simple.data.frame <- data.frame( name=c("Toni","Mary", "John"), height = c(56, 72.1, 89.6), class = c(1,2,3))
 example.simple.data.frame
 
 
# Create a data frame named mydata, and each variable will receive the default name
# V1, V2,. . . and writing can be accessed individually mydata $ V1, mydata $ V2,
#. . . Or writing mydata ["PATIENT"], mydata ["DRUG"]. . . Or, also writing mydata [,
# 1], mydata [2].

mydata$PATIENT 
mydata$DRUG

#sAVE ONLY THE DRUG=A:
mydata.A <- subset(mydata,DRUG=="A" )
write.table(mydata.A, file = "TBP DRUG TRIAL(1).txt", quote = FALSE)   #SAVE THE DATA IN A FILE



x <- 1:30 # Generating a sequence of 30 numbers from 1 to 30
x
seq(1, 50, 0.5) # Generating a sequence of random numbers

expand.grid(a=c(60,80), p=c(100, 300), sexo=c("Male", "Female"))  #all the combinations

n <-1000                                                                  
rnorm(n, mean=0, sd=1) #100 numbers of normal distributed numbers (mean= 0 and sd = 1)   

#A little bit sofisticated data.frame to generate a clinical trial data
# simulated input values
n      = 100
mu     = 100
sd     = 10
mu.d   = 20
age.mu = 50
age.sd = 10

# fix the seed for random number generation 
set.seed(123)
# use "rnorm" to generate random normal
age         = rnorm(n, age.mu, age.sd)
bp.base     = rnorm(n,mu,sd)
bp.end      = rnorm(n,mu,sd)
# take the difference between endpoint and baseline
bp.diff     = bp.end-bp.base
# put the data together using "cbind" to column-bind
dat4placebo = round(cbind(age,bp.base,bp.end,bp.diff),digits = 0)

#AND FINALLY A DATA FRAME
data5.placebo = round(data.frame(age,bp.base,bp.end,bp.diff),digits = 0)

#####################################################
#### FACTOR, MATRIX
#####################################################

# A factor includes not only the values for a categorical variable, but
# Also the different possible levels of this variable (even if they are present in the data).
factor(1:3)   
factor(1:3, levels=1:5)  
factor(1:3, labels=c("A", "B", "C")) #type of drug
factor(1:5, exclude=4)  


# Matrix. A matrix is actually a vector with an additional attribute (dim) which in turn is a
# Numeric vector of length 2, which defines the number of rows and columns of the matrix

matrix(data=7, nr=6, nc=6)
matrix(1:6, 2, 3) #2 files and 3 columns

#time series (example for epidemiology)
births <- scan("http://robjhyndman.com/tsdldata/data/nybirths.dat")
birthstimeseries <- ts(births, frequency=12, start=c(1946,1))
birthstimeseries
plot.ts(birthstimeseries)

#mathematical expression
x <- 3; y <- 2.5; z <- 1
 exp1 <- expression(x / (y + exp(z)))   
 exp1 
 eval(exp1)   
 

#####################################################
#### IMPORT FILES AND MANAGING DATA
#####################################################

# more information in: http://www.milanor.net/blog/?p=779

#Read MS EXCEL DATA
microarray.expression = read.table("GSE1561_apocrine_tumours_rma.csv", header = TRUE, dec = ",", sep =";" )
microarray.expression
head(microarray.expression)
help(read.table)

#Copy the table from the "clip-board", memory
mytable = read.table("clipboard")




###### Other files SAS, SPSS, ETC



#Reading SPSS File
#Step 1 : Install the package once
install.packages("foreign")
#Step 2 : Define path in the code below
library("foreign")
read.spss("Survival.sav",
          use.value.labels = TRUE,
          to.data.frame = TRUE)


############################(DATA-BASES: More complicated data structures)############################################################################################################

#MYSQL

#So far, we have dealt with small datasets that easily fit into your computer’s memory. But what about datasets that are too large for your computer to handle as a whole? In this case, storing the data outside of R and organizing it in a database is helpful. Connecting to the database allows you to retrieve only the chunks needed for the current analysis.

#Even better, many large datasets are already available in public or private databases. You can query them without having to download the data first.

#see example of MAMMALS at: https://datacarpentry.org/R-ecology-lesson/05-r-and-databases.html
install.packages(c("dbplyr", "RSQLite"))
dir.create("data", showWarnings = FALSE)
download.file(url = "https://ndownloader.figshare.com/files/2292171",
              destfile = "data/portal_mammals.sqlite", mode = "wb")
#Connecting to databases
library(dplyr)
library(dbplyr)

mammals <- DBI::dbConnect(RSQLite::SQLite(), "data/portal_mammals.sqlite")
src_dbi(mammals)

#Querying the database with the SQL syntax
#To connect to tables within a database, you can use the tbl() function from dplyr. This function can be used to send SQL queries to the database. To demonstrate this functionality, let’s select the columns “year”, “species_id”, and “plot_id” from the surveys table:
RESULTS<-tbl(mammals, sql("SELECT year, species_id, plot_id FROM surveys"))
View(data.frame(RESULTS))

surveys <- tbl(mammals, "surveys")
surveys %>%
  select(year, species_id, plot_id)
head(surveys, n = 10)


# see: http://www.stat.berkeley.edu/~nolan/stat133/Fall05/lectures/SQL-R.pdf
# see connect with data-bases: http://www.statmethods.net/input/dbinterface.html






#####################################################
#### Descriptive and graphical analysis
#####################################################


# R offers many possibilities for a descriptive and exploratory data an'alisis.
# Allows also produce varied and high-quality graphic outputs. In this
# Activity the main instructions and functions necessary to perform these
# Tasks.

#  Descriptive and exploratory analysis -------------------------------------------------------------------

# The function summary provides a statistical summary of an object. If it is a
# Vector number, the summary gives us the minimum, the first quartile, median, average,
# The third quartile and maximum of the data. To illustrate this funci'on, we generate a vector
# 100 random data from a normal distribution with mean 5 and standard deviation 3.
?rnorm
x<-rnorm(100,5,3)
summary(x)
xna<-c(x,rep(NA,5))
xna
summary(xna)
summary(x)[3:4]


# Open a clinical data frame
datR4CTDA_DBP <- read.csv("datR4CTDA_DBP.csv", sep=";")

#list the variables: Subject  TRT	DBP1	DBP2	DBP3	DBP4	DBP5	Age	Sex
summary(datR4CTDA_DBP)

#We can do a box-plot
boxplot(DBP1~TRT, datR4CTDA_DBP, las=1, xlab="Treatment", ylab="DBP at Baseline", col=blues9)

#Descriptive statistics
# The function mean (x) calculates the average of a vector or matrix x. The VAR function (x) calculates
# Variance estimators of a vector x, the covariance matrix between columns
# An array of data x, the covariance between the x and y vectors (var (x, y)) or matrix
# Covariance between the columns of the x and y matrices (var (x, y)). Some examples:

mean(datR4CTDA_DBP$DBP1)
mean(datR4CTDA_DBP$DBP1,na.rm=T)
var(datR4CTDA_DBP$DBP1)
sd(datR4CTDA_DBP$DBP1)
var(datR4CTDA_DBP[,3:6]) #var-cov matrix



# Other indicators of interest are median, interquartile range or the correlation between
# Two numeric variables:
median(datR4CTDA_DBP$Age)
min(datR4CTDA_DBP$Age)
max(datR4CTDA_DBP$Age)
IQR(datR4CTDA_DBP$Age)#  interquartile range of the x values
cor(datR4CTDA_DBP[,3:8])
round(cor(datR4CTDA_DBP[,3:8]),3)


# The quantile function (x, p) calculates the empirical quantile of x to a 
# vector of probabilities p. For example,
BMI<-rnorm(n=1000, m=24.2, sd=2.2) 
summary(BMI)
hist(BMI, breaks=20, main="Breaks=20")
hist(BMI, breaks=5, main="Breaks=5")
hist(BMI, freq=FALSE, main="Density plot", col="red",breaks = 12)
hist(BMI, freq=FALSE, main="Density plot", col="red",breaks = 120)
curve(dnorm(x, mean=mean(BMI), sd=sd(BMI)), add=TRUE, col="darkblue", lwd=2)
quantile(BMI,0.3)
quantile(BMI,c(0.05, 0.1,0.3,0.6,0.8, 0.95))
quantile(BMI,seq(.2,.9,.1))

#In case of a categorical variable we are usually interested in the representation of the data in the form of a table with the absolute and / or relative frequencies. In case of a couple of variables
#categorical, a contingency table is used to represent the joint distribution of both.

attach(datR4CTDA_DBP)
table(Sex) #SEX
table(TRT) #TREATMENT
table(Sex,TRT)
detach(datR4CTDA_DBP)

#use of library catspec to do tables
library(catspec)
?ctab
attach(datR4CTDA_DBP)
ctab(Sex)
ctab(TRT)
ctab(as.factor(TRT))
ctab(Sex,TRT)
ctab(Sex,TRT,type=c("n","r"),addmargins=T)



#  Graphs --------------------------------------------------------------------------------------------
 
 split.screen(c(1, 2))  #graphic subscreens
 mat <- matrix(1:4, 2, 2)
 mat
 layout(mat)
 layout.show(4) #show 4 screens
 
 layout(matrix(1:6, 3, 2))
 layout.show(6) #show 6 screens


# Example with plot
x <- rnorm(100, 3, 2)
y <- rnorm(100, 23, 10)
layout.show(1)
plot(x, y)


plot(x, y, xlab="Numbers at random X", ylab="Numbers at random Y",
xlim=c(-5, 5), ylim=c(1, 70), pch=22, col="red",
bg="yellow", bty="l", tcl=0.4,
main="episodes of illness", las=1, cex=1.5)                                              

# More graphs
data(VADeaths) 
VADeaths  
barplot(VADeaths)
barplot(VADeaths,beside=T)



# Mathematical functions.
 x = seq(-10,10)  # Generamos los n?meros -10, -9,....,9, 10
 y = x^2 + 3          # Generamos los cuadrados de dichos n?meros
 plot(x,y)       # Graficamos     
 
 
# Regression in R
 x <- rnorm(100)
 y <- 2 + 1.9*x + rnorm(100)
 reg <- lm(y ~x)
 summary(reg)

 # graph
 plot(x,y, xlab = "Var X", ylab= "Var Y")
 abline(reg, col = 2)
 legend('topleft', c('Real','Adjusted'), pch = c(1, NA), lty = c(NA, 1), col
 = c(1,2))


 #########################################
 ### Extra Exercises for Practice ########
 #########################################
 
 # 1) Work with Factors and Subsets:
   
 # Using the simulated data frame you created, add a new categorical variable. 
 # For instance, you could add a variable called treatment_group with two levels, 
 # "Group A" and "Group B," assigned randomly to your subjects. 
 # Use the factor() function to ensure R recognizes this as a categorical variable.
 
  
 # 2) Create a subset of your data frame that includes only the subjects from "Group A."
 
 # 3) Calculate the mean and standard deviation of a numeric variable (e.g., cholesterol or weight) for this subset.
 
 # 4) Combine Data and Create a Plot:
   
 # 4.1) Create a second data frame with 50 new simulated subjects, but use a different mean for one of your variables (e.g., a higher cholesterol mean). This will represent a separate, but related, group.
 
 # 4.2) Using a function like rbind(), combine this new data frame with your original one.
 
 # 4.3) Create a box plot that shows the distribution of a numeric variable, with separate box plots for the two groups you combined. This will visually demonstrate the difference in their means.

                                                              